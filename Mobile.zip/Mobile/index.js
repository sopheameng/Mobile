const express = require('express')
const app = new express();
const router = require('./routes/admin');
const path = require('path');
const port=3000;


app.set('view engine', 'ejs');
app.set('views','views');
app.use(express.static(path.join(__dirname, 'public')));
app.use('/public/assets/css',express.static(__dirname + '/public/assets/css'));
app.use('/public/assets/images',express.static(__dirname + '/public/assets/images'));

app.use(router);
app.use('/admin',router);

app.listen(port);
