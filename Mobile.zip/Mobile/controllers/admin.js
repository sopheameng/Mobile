exports.getHomePage = (req, res, next) => {
    res.render('Homepage', {
        pageTittle: 'HomePage'
    })
}

exports.getPromotionPage = (req, res, next) => {
    res.render('PromotionPage', {
        pageTittle: 'PromotionPage'
    })
}

exports.getContactUsPage = (req, res, next) => {
    res.render('ContactUsPage', {
        pageTittle: 'ContactUsPage'
    })
}

exports.getAboutUsPage = (req, res, next) => {
    res.render('AboutUsPage', {
        pageTittle: 'AboutUsPage'
    })
}

exports.getAppleProduct = (req, res, next) => {
    res.render('Apple_Section', {
        pageTittle: 'AppleProduct'
    })
}

exports.getSamsungProduct = (req, res, next) => {
    res.render('Samsung_Section', {
        pageTittle: 'SamsungProduct'
    })
}

exports.getOnePlusProduct = (req, res, next) => {
    res.render('OnePlus_Section', {
        pageTittle: 'OnePlusProduct'
    })
}

exports.getHuaweiProduct = (req, res, next) => {
    res.render('Huawei_Section', {
        pageTittle: 'HuaweiProduct'
    })
}

exports.getOppoProduct = (req, res, next) => {
    res.render('Oppo_Section', {
        pageTittle: 'OppoProduct'
    })
}

exports.getXiaomiProduct = (req, res, next) => {
    res.render('Xiaomi_Section', {
        pageTittle: 'XiaomiProduct'
    })
}

exports.getVivoProduct = (req, res, next) => {
    res.render('Vivo_Section', {
        pageTittle: 'VivoProduct'
    })
}
