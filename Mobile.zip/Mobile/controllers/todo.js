exports.createTodo = (req, res, next) =>{
    // create todo and store in database
} 

exports.updateTodo = (req, res, next) =>{
    // update todo 
}

exports.getTodos = (req, res, next) =>{
    // get list of todo 
    console.log('get todo list');
    res.send('todo list');
}