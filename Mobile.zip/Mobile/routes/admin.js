const path = require('path');
const express = require('express');
const router = express.Router();

const adminController = require('../controllers/admin');
router.get('/', adminController.getHomePage);
router.get('/Promotion', adminController.getPromotionPage);
router.get('/ContactUs', adminController.getContactUsPage);
router.get('/AboutUs', adminController.getAboutUsPage);

router.get('/Apple', adminController.getAppleProduct);
router.get('/Samsung', adminController.getSamsungProduct);
router.get('/OnePlus', adminController.getOnePlusProduct);
router.get('/Huawei', adminController.getHuaweiProduct);
router.get('/Oppo', adminController.getOppoProduct);
router.get('/Xiaomi', adminController.getXiaomiProduct);
router.get('/Vivo', adminController.getVivoProduct);

module.exports = router;