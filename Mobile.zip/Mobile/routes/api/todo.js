const express = require('express');
const router = express.Router();
const todoController = require('../../controllers/todo');

router.post('/todo', todoController.createTodo );

router.put('/todo', todoController.updateTodo );

router.delete('/todo', todoController.deleteTodo );

router.get('/todo', todoController.getTodo );

module.exports = router;